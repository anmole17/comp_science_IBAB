#include<stdio.h>

int main()
{
	int i,a[10];
	a[0]=10;
	a[1]=20;
	a[2]=30;
	a[3]=40;
	a[4]=50;
	a[5]=60;

	/* Print the numbers in the array */
	for(i=0;i<6;i++)
	{
		printf("%d\n",a[i]);
	}
}
