#Python assignment:
As mentioned in the assignment the C programms have to be done in python, these questions are named `q1_c.py`,etc.
Normal questions are named `q1.py`.
