#!/usr/bin/python3
#Write a program that takes 3 strings as parameters, concatenate them all and print the final string. Try once using strcat() of string.h and once without the help of library.


string1=input("Enter string 1:\n")
string2=input("Enter string 2:\n")
string3=input("Enter string 3:\n")

join_string=string1+string2+string3

print("Concatenated string:", join_string)
