/*Write a program which takes one character and prints the same (use %c format specifier).
Also try by using %d format specifier. Note down the findings. Keep an eye on those numbers.
*/

#include<stdio.h>

int main()
{
	char a;
	printf("Enter a character:");
	scanf("%c",&a);
	printf("The character is: %d \n",a);
	return(0);
}
