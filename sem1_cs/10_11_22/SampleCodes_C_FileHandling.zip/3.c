#include<stdio.h>

int main()
{
	char arr[100];
	scanf("%[^\n]s",arr);
	printf("%s",arr);
}
