#include<stdio.h>

int main()
{
	int i;
	i=5;
	while(i>10)
{
	printf("hi\n");
}
}

