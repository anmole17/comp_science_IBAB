#include<stdio.h>
#include<stdlib.h>

int main()
{
FILE *fptr;
fptr=fopen("1.txt","w");
fprintf(fptr,"HELLO IBAB");
fclose(fptr);

}
