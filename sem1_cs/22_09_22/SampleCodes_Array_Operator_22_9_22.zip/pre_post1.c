#include<stdio.h>

int main()
{
	int i,j;
	i=10;
	j=(++i);
	printf("%d \n",j);

	i=20;
	j=(i++);
	printf("%d \n",j);

	return(0);
}
