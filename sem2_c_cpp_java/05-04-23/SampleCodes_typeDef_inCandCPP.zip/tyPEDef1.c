#include<stdio.h>
typedef int myInt;

int main()
{
	int i;
	i=10;
	myInt k=22;
	printf("%d %d\n",i,k);
}
