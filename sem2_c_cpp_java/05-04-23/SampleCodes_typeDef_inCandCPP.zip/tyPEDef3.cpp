#include <iostream>
typedef class S1 {int i;float j;public:void f1(){}}myHouse;

int main()
{
	myHouse house1;
	house1.f1();
}
