#include <stdio.h>
typedef struct s1 {int i;float j;}myStruct;

int main()
{
	myStruct a1;
	a1.i=10;
	a1.j=22.34;
}
