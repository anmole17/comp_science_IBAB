#include<stdio.h>
#define ten "HI" 

int main()
{
	printf("%s \n",ten);
	ten="IBAB";
}
