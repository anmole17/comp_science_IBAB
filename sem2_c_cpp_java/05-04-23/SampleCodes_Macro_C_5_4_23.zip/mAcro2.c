#include<stdio.h>
#define ten 10 

int main()
{
	printf("%d \n",ten);
	ten=12;

}
