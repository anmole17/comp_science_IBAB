import java.util.*;

class B1 
	{
		public void f2()
		{
			System.out.println("Hello from B1");
		}
		public static void main(String args[])
		{
			B1 b1=new B1();
			b1.f2();
		}
	};


