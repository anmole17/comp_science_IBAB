#include<iostream>
#include<cmath>
#include<bits/stdc++.h>
using namespace std;

int main()
{
	double num=3.123234;
	cout << setprecision(5) << num << endl;
}
