#include<iostream>
using namespace std;

class 
{
	public:
		void f1()
		{
			cout << "hi" << endl;
		}
}a1,a2;

int main()
{
	a1.f1();
	a2.f1();
}
