#include<stdio.h>
int main()
{
	printf("Hello\n");
	return(0);
}
/* Not a preferred way of working. This is a look alike of a C program */
