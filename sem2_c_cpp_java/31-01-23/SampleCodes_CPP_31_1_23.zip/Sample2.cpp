#include<cstdio>
int main()
{
	printf("Hello\n");
	return(0);
}
/* preferred way of working with a C Code but use C++ Compiler */
