#include<iostream>
using namespace std;
class A1
{
	public :
		void f1()
		{
			cout << "Hello from A1" << endl;
		}
		void f1(int x)
		{
			cout << "Hello from f1(x) of A1" << endl;
		}
		void f1(int x,int y)
		{
			cout << "Hello from f1(x,y) of A1" << endl;
		}
};
int main()
{
	class A1 a1;
	a1.f1();
	a1.f1(10);//Param I am passing just to differentiate the Fn 
	a1.f1(10,20);// Param is passed only to differentiate the Fn
}
