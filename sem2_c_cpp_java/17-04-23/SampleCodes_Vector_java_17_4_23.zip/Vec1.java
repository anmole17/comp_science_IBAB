import java.util.*;

class A1
{
	public static void main(String args[])
	{
		Vector v1 = new Vector();
		v1.add(10);
		v1.add("hi");
		v1.add(10.25);
		System.out.println(v1);
	}
};
