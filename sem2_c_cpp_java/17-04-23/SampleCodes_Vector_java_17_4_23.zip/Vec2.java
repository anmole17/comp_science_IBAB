import java.util.*;

class A1
{
	public static void main(String args[])
	{
		Vector v1 = new Vector();
		System.out.println(v1.capacity());
		System.out.println(v1.size());
	}
};
