#include<iostream>

int main()
{
	std::cout << "HI" << endl;
	std::cout << "How are you?" << endl;
	return(0);
}
