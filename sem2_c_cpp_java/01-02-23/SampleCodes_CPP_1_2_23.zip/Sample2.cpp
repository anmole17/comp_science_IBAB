#include<iostream>
using namespace std;

int main()
{
	cout << "HI" << endl;
	cout << "How are you?" << endl;
	return(0);
}
