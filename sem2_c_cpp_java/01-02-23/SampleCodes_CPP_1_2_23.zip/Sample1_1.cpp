#include<iostream>

int main()
{
	std::cout << "HI";
	std::cout << "How are you?";
	return(0);
}
