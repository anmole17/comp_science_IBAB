#include<iostream>
using namespace std;
int main()
{
	int num1,res;
	cout << "Enter a number : -->";
	cin >> num1;
	cout << "The Entered Number is :" << num1 << endl;
	res=(num1)*(num1);
	cout << "The Square of the number is :-->" << res;
	return(0);
}
