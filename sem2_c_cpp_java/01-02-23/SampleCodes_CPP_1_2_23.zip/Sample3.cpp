#include<iostream>
using namespace std;
int main()
{
	cout << "HI";
	cout << "How are you?";
	return(0);
}
