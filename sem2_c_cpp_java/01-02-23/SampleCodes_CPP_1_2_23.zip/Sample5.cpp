#include<iostream>
using namespace std;
int main()
{
	int num1;
	cout << "Enter a number : -->";
	cin >> num1;
	cout << "The Entered Number is :" << num1 << endl;
	cout << "The Square of the number is :-->" << (num1)*(num1);
	return(0);
}
