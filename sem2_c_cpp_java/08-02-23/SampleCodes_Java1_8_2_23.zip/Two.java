
class B1
{
	public void f1()
	{
		System.out.println("HI");
	}
};
class A1
{
	public static void main(String args[])
	{
		System.out.println("hello");
		B1 b1 = new B1();
		b1.f1();
	}
};

